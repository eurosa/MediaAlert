package com.example.aatick.medialart;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.GregorianCalendar;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class AlarmService extends Service {
    public static final String CREATE = "CREATE";
    public static final String CANCEL = "CANCEL";
    private SQLiteDatabase newDB;
    private ArrayList<String> results=new ArrayList<String>();
    private PendingIntent alarmIntent;
    private PendingIntent alarmIntent_follow;
    String dateString1;
    private IntentFilter matcher;
    String dateString2;
    String currentDateTime;
    String dateString;
    String database_time;
    public AlarmService() {
        super();
        matcher = new IntentFilter();
        matcher.addAction(CREATE);
        matcher.addAction(CANCEL);
    }


    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
     Toast.makeText(this, "gama", Toast.LENGTH_LONG).show();
//        String action = intent.getAction();
//        String notificationId = intent.getStringExtra("notificationId");

//        if (matcher.matchAction(action)) {
            execute();
//        Intent intentAlarm = new Intent(this, AlarmReciever.class);
//        sendBroadcast(intentAlarm);
//        if (currentDateTime.equals(database_time)) {
            Long time = new GregorianCalendar().getTimeInMillis();
            System.out.println("Gregorian" + time);

            // create an Intent and set the class which will execute when Alarm triggers, here we have
            // given AlarmReciever in the Intent, the onRecieve() method of this class will execute when
            // alarm triggers and
            //we will write the code to send SMS inside onRecieve() method pf Alarmreciever class
            Intent intentAlarm = new Intent(this, AlarmReciever.class);

//            sendBroadcast(intentAlarm);

            // create the object
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//        Intent intent = new Intent(context, AlarmReceiver.class);
            // I have changed the context to this
            alarmIntent = PendingIntent.getBroadcast(this, 0, intentAlarm, 0);

// schedule for every 10 seconds
            Toast.makeText(AlarmService.this, "dgdgdgd", Toast.LENGTH_SHORT).show();
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, SystemClock.elapsedRealtime(),60 * 1000, alarmIntent);

//        }
//        }

        return super.onStartCommand(intent, flags, startId);
    }

    private void execute() {


        // time at which alarm will be scheduled here alarm is scheduled at 1 day from current time,
        // we fetch  the current time in milliseconds and added 1 day time
        // i.e. 24*60*60*1000= 86,400,000   milliseconds in a day
//        Long time = new GregorianCalendar().getTimeInMillis();
//        System.out.println("Gregorian" + time);
//
//        // create an Intent and set the class which will execute when Alarm triggers, here we have
//        // given AlarmReciever in the Intent, the onRecieve() method of this class will execute when
//        // alarm triggers and
//        //we will write the code to send SMS inside onRecieve() method pf Alarmreciever class
//        Intent intentAlarm = new Intent(this, AlarmReciever.class);
//        sendBroadcast(intentAlarm);
//
//        // create the object
//        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
////        Intent intent = new Intent(context, AlarmReceiver.class);
//        // I have changed the context to this
//        alarmIntent = PendingIntent.getBroadcast(this, 0, intentAlarm, 0);


        //System time here
//        Date date = new Date();
//        Timestamp timestamp = new Timestamp(date.getTime());
//        System.out.print("lll" + timestamp);
//        //query for date and time matching to show setting alarm data
//
//        Date date1 = null;
//        try {
//            date1 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss.SSSSSSSSS").parse(String.valueOf(timestamp));
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        String currentDateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm").format(date1);
//        System.out.println("mm" + currentDateTime);


        //database query for matching and give time interval
//        try {
//            DataBaseHelper dbHelper = new DataBaseHelper(this.getApplicationContext());
//            newDB = dbHelper.getWritableDatabase();
//            Cursor c = newDB.rawQuery("SELECT medicine_name, date,time_interval,time FROM media_store where id >0", null);
//
//            if (c != null) {
//                if (c.moveToFirst()) {
//                    do {
//                        String medicineName = c.getString(c.getColumnIndex("medicine_name"));
//                        String date_alarm = c.getString(c.getColumnIndex("date"));
//                        String time_alarm = c.getString(c.getColumnIndex("time"));
//                        String time_interval_alarm = c.getString(c.getColumnIndex("time_interval"));
//
//                        dateString1 = date_alarm;
//                        Date timeFormatter = null;
//                        Date date2 = null;
//                        try {
//
//                            date2 = new SimpleDateFormat("dd-MM-yyyy").parse(dateString1);
//                            timeFormatter = new SimpleDateFormat("h:mm a").parse(time_alarm);
//                            dateString2 = new SimpleDateFormat("yyyy-MM-dd").format(date2);
//                            dateString = new SimpleDateFormat("hh:mm").format(timeFormatter);
//                        } catch (ParseException e) {
//                            e.printStackTrace();
//                        }
//
//
//                        database_time = dateString2 + " " + dateString;
//
//
//                        results.add("Name: " + medicineName);
//                        Log.d("radhason_power", database_time);
//                    } while (c.moveToNext());
//                }
//            }
//        } catch (SQLiteException se) {
//            Log.e(getClass().getSimpleName(), "Could not create or Open the database");
//        }


        //set the alarm for particular time
//        alarmManager.set(AlarmManager.RTC_WAKEUP, time, PendingIntent.getBroadcast(this, 1, intentAlarm, PendingIntent.FLAG_UPDATE_CURRENT));
        Toast.makeText(this, "Alarm Scheduled for Tomorrow", Toast.LENGTH_LONG).show();


    }




}
